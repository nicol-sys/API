package com.example.api;
import android.view.View;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private EditText editTextID;
    private TextView textViewCampo1, textViewCampo2, textViewCampo3, textViewCampo4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextID = findViewById(R.id.editTextID);
        textViewCampo1 = findViewById(R.id.textViewCampo1);
        textViewCampo2 = findViewById(R.id.textViewCampo2);
        textViewCampo3 = findViewById(R.id.textViewCampo3);
        textViewCampo4 = findViewById(R.id.textViewCampo4);
    }

    public void obtenerDatos(View view) {

            final String id = editTextID.getText().toString();
            final String url = "http://10.20.36.64/api?id=" + id; // Cambia la URL a tu servidor y ruta real
            AsyncTask<Void, Void, String> task = new AsyncTask<Void, Void, String>() {

                @Override
                protected String doInBackground(Void... voids) {
                    try {
                        URL apiUrl = new URL(url);
                        HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();
                        // Configurar la solicitud HTTP GET
                        connection.setRequestMethod("GET");
                        connection.connect();
                        // Leer la respuesta BufferedReader
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            response.append(line);
                        }
                        bufferedReader.close();
                        return response.toString();
                    } catch (Exception e) {
                        e.printStackTrace();
                        return "Error en la conexión: " + e.getMessage();
                    }
                }

                @Override
                protected void onPostExecute(String result) {
                    super.onPostExecute(result);
                    if (result != null) {
                        try {
                            JSONArray jsonArray = new JSONArray(result);
                            JSONObject jsonObject = jsonArray.getJSONObject(0);
                            // Obtener los datos y mostrarlos en los TextView
                            String CUADRADO = jsonObject.getString("campo1");
                            String CUBO = jsonObject.getString("campo2");
                            String RAIZ_CUBICA = jsonObject.getString("campo3");
                            String RAIZ_CUADRADA = jsonObject.getString("campo4");
                            textViewCampo1.setText(CUADRADO);
                            textViewCampo2.setText(CUBO);
                            textViewCampo3.setText(RAIZ_CUBICA);
                            textViewCampo4.setText(RAIZ_CUADRADA);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            };
            task.execute();
        }
    }



